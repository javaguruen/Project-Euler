package euler

import org.junit._
import Assert._

class Euler03Test{
 /* @Test
  def _3isPrime : Unit = {
    val euler3 = new Euler03
    assertTrue("3 primtall", euler3.isPrime(3) )
  }

  @Test
  def _2isPrime : Unit = {
    val euler3 = new Euler03
    assertTrue("2 primtall", euler3.isPrime(2) )
  }

  @Test
  def _4isPrime : Unit = {
    val euler3 = new Euler03
    assertFalse("4 ikke primtall", euler3.isPrime(4) )
  }

  @Test
  def _151isNotPrime : Unit = {
    val euler3 = new Euler03
    assertFalse("15 ikke primtall", euler3.isPrime(15) )
  }

  @Test
  def factor6 : Unit = {
    val euler3 = new Euler03
    var factors = euler3.factor(6)
    assertArrayEquals("factor(6)=(2,3)", Array(2,3),  factors)
  }

  @Test
  def factor9 : Unit = {
    val euler3 = new Euler03
    assertArrayEquals("factor(9)=(3,3)", Array(3,3), euler3.factor(9) )
  }
*/


}